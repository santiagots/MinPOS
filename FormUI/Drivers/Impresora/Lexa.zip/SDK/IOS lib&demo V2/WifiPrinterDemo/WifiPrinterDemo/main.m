//
//  main.m
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
