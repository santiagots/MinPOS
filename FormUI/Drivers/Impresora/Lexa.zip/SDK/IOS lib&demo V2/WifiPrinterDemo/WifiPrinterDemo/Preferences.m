//
//  Preferences.m
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import "Preferences.h"
#import "WifiPrinter.h"
#import "AppDelegate.h"

@implementation Preferences
@synthesize txtContent;
@synthesize printer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = LANG(@"打印选项");
}

- (void)viewDidUnload
{
    [self setTxtContent:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}





- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (IBAction)btnPrintText:(id)sender
{
    [printer Begin];
    if(IS_LANG_EN)
    {
        [printer ImportData:@"This is a text printer tester, print:ABCabc123456\n"];
    }
    else
    {
        [printer ImportData:@"这是一个文本打印测试程序,打印出的文本为:ABCabc中文123456\n"];
    }
    [printer Excute];
    [printer ClearData];
}

- (IBAction)btnPrintPic:(id)sender
{
    UIImage *img = [UIImage imageNamed:@"stamp.bmp"];
    [printer BeginPrintImage:img];
}

- (IBAction)btnPrintBarcode:(id)sender
{
    if ([[txtContent text] length] > 16)
    {
        MSGBOX(LANG(@"最多输入16个数字"));
        return;
    }
    
    NSCharacterSet *numberSet = [NSCharacterSet decimalDigitCharacterSet];
    for(NSInteger i =0; i< [txtContent.text length]; i++)
    {
        unichar ch = [txtContent.text characterAtIndex:i];
        if(![numberSet characterIsMember:ch])
        {
            MSGBOX(LANG(@"最多输入16个数字"));
            return;
        }
    }
    
    NSData *data = [[txtContent text] dataUsingEncoding: NSASCIIStringEncoding];
    [printer AddBarCodePrint:RT_BCS_CODE128 :data];
    [printer Excute];
    [printer ClearData];
}

- (IBAction)btnPrintInvoice:(id)sender
{
    if(IS_LANG_EN)
    {
        [printer Begin];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer SetAlignMode:(Byte)1];
        [printer SetLineSpacing:(Byte)50];
        [printer ImportData:@"China Mobile Rrepaid Receipts"];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        //[printer LF];
        //[printer Excute];
        //[printer ClearData];
        [printer SetAlignMode:(Byte)0];
        //[printer AddLeftMargin(0);
        [printer ImportData:@"Payer:    Qinghua University"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"Prepaid date:    2013-03-08"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"Receiver:    Beijing mobile co., LTD"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"Prepaid sum:    200.00 RMB"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"Seal:"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
    }
    else
    {
        [printer Begin];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer SetAlignMode:(Byte)1];
        [printer SetLineSpacing:(Byte)50];
        [printer ImportData:@"中国移动通信集团充值小票"];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        //[printer LF];
        //[printer Excute];
        //[printer ClearData];
        [printer SetAlignMode:(Byte)0];
        //[printer AddLeftMargin(0);
        [printer ImportData:@"付款单位:    清华大学"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"充值日期:    2013-03-08"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"收款单位:    北京移动有限公司"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"充值金额:    ￥200.00"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"金额大写:    贰佰元整"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
        [printer ImportData:@"公章:"];
        [printer LF];
        [printer Excute];
        [printer ClearData];
    }
    
}

- (IBAction)btnPrintTable:(id)sender
{
    if(IS_LANG_EN)
    {
        [printer Begin];
        
        Byte byteData[] = {0x1d,0x21,0x01};
        NSData *data = [NSData dataWithBytes:byteData length:3];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"---------------------------------------\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@" station   hangzhou   arrive   baoying \n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"---------------------------------------\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@" quantity  1/0222     number   55555555\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"---------------------------------------\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@" name      [send]sunj/fuhq           \n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"---------------------------------------\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@" operate   test       name     hangzhou\n"];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"---------------------------------------\n"];
        [printer Excute];
        [printer ClearData];
    }
    else
    {
        [printer Begin];
        
        Byte byteData[] = {0x1d,0x21,0x01};
        NSData *data = [NSData dataWithBytes:byteData length:3];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"┏━━┳━━━┳━━┳━━━━┓\n"];
        [printer ImportData:data Len:3];//设置倍高
        NSString *str = [NSString stringWithFormat:@"┃发站┃%@  ┃到站┃%@    ┃\n",@"杭州",@"宝应"];
        [printer ImportData:str];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"┣━━╋━━━╋━━╋━━━━┫\n"];
        [printer ImportData:data Len:3];//设置倍高
        str = [NSString stringWithFormat:@"┃件数┃%1d/%-4d┃单号┃%-8d┃\n",1,222,55555555];
        [printer ImportData:str];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"┣━━╋━━━┻━━┻━━━━┫\n"];
        [printer ImportData:data Len:3];//设置倍高
        str = [NSString stringWithFormat:@"┃姓名┃%@     ┃\n",@"【送】孙俊/符和清"];
        [printer ImportData:str];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"┣━━╋━━━┳━━┳━━━━┫\n"];
        [printer ImportData:data Len:3];//设置倍高
        str = [NSString stringWithFormat:@"┃操作┃%@  ┃名称┃%@    ┃\n",@"测试",@"杭州"];
        [printer ImportData:str];
        [printer ImportData:data Len:3];//设置倍高
        [printer ImportData:@"┗━━┻━━━┻━━┻━━━━┛\n"];
        [printer Excute];
        [printer ClearData];
    }
    
}
@end
