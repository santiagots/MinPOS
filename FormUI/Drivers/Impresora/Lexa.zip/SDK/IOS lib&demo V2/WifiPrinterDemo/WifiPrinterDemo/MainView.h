//
//  MainView.h
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WifiPrinterDelegate.h"
#import "UIKeyboardViewController.h"

@class WifiPrinter;
@interface MainView : UIViewController<UIKeyboardViewControllerDelegate,UITextViewDelegate,UITextFieldDelegate,WifiPrinterDelegate>
{
    
}
- (IBAction)btnConnect:(id)sender;
- (IBAction)btnPrint:(id)sender;
- (IBAction)btnTest:(id)sender;
- (IBAction)btnPreferencesClick;

@property (strong, nonatomic) WifiPrinter *printer;

@property (strong, nonatomic) IBOutlet UITextField *txtIP;
@property (strong, nonatomic) IBOutlet UITextField *txtPort;
@property (strong, nonatomic) IBOutlet UITextView *txtContent;
@property (strong, nonatomic) IBOutlet UIButton *btn;

@property (strong, nonatomic) IBOutlet UISwitch *swDoubleWidth;
@property (strong, nonatomic) IBOutlet UISwitch *swDoubleHeight;
@property (strong, nonatomic) IBOutlet UISwitch *swUnderLine;
@property (strong, nonatomic) IBOutlet UISwitch *swBold;
@property (strong, nonatomic) IBOutlet UISwitch *swSmallFont;
@property (strong, nonatomic) IBOutlet UISwitch *swToWhite;
@property (strong, nonatomic) IBOutlet UILabel *labStatus;
@end
