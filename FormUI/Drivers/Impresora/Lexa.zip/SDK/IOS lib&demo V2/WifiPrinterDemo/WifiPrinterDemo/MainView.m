//
//  MainView.m
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import "MainView.h"
#import "AppDelegate.h"
#import "Preferences.h"
#import "WifiPrinter.h"

@implementation MainView
@synthesize printer;
@synthesize txtIP;
@synthesize txtPort;
@synthesize txtContent;
@synthesize btn;
@synthesize swDoubleWidth;
@synthesize swDoubleHeight;
@synthesize swUnderLine;
@synthesize swBold;
@synthesize swSmallFont;
@synthesize swToWhite;
@synthesize labStatus;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        printer = [[WifiPrinter alloc] initWithDelegate:self];
        UIKeyboardViewController *keyBoardController=[[UIKeyboardViewController alloc] initWithControllerDelegate:self];
        [keyBoardController addToolbarToKeyboard];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = LANG(@"示例");
    txtContent.delegate = self;
}

- (void)viewDidUnload
{
    [self setPrinter:nil];
    [self setTxtIP:nil];
    [self setTxtContent:nil];
    [self setTxtPort:nil];
    [self setSwDoubleWidth:nil];
    [self setSwDoubleHeight:nil];
    [self setSwUnderLine:nil];
    [self setSwBold:nil];
    [self setSwSmallFont:nil];
    [self setSwToWhite:nil];
    [self setBtn:nil];
    [self setLabStatus:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}





- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

#pragma - UIKeyboardViewController delegate methods

- (void)alttextFieldDidEndEditing:(UITextField *)textField
{
    //NSLog(@"%@", textField.text);
}

- (void)alttextViewDidEndEditing:(UITextView *)textView {
    //NSLog(@"%@", textView.text);
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    for(NSInteger i =0; i< [text length]; i++)
    {
        unichar ch = [text characterAtIndex:i];
        if(IS_CH_SYMBOL(ch))
            return NO;
    }
    return YES;
}

//============================================================================================
- (IBAction)btnConnect:(id)sender
{
    [txtIP resignFirstResponder];
    [txtPort resignFirstResponder];
    [txtContent resignFirstResponder];

    if ([[[btn titleLabel] text] isEqualToString:LANG(@"连接")])
    {
        [printer connectHost:[txtIP text] PORT:[[txtPort text] intValue]];
    }
    else if ([[[btn titleLabel] text] isEqualToString:LANG(@"断开")])
    {
        [printer disconnect];
    }
    
}

- (void)onConnected:(BOOL)isSucceed
{
    if (isSucceed)
    {
        [btn setTitle:LANG(@"断开") forState:UIControlStateNormal];
        labStatus.text = LANG(@"已连接");
    }
    else
    {
        MSGBOX(LANG(@"连接失败！"));
    }

}

- (void)onDisconnected:(BOOL)isSucceed
{
    if (isSucceed)
    {
        [btn setTitle:LANG(@"连接") forState:UIControlStateNormal];
        labStatus.text = LANG(@"已断开");
    }
    else
    {
        MSGBOX(LANG(@"断开失败！"));
    }
}

- (IBAction)btnPrint:(id)sender
{
    [printer Begin];
    if(swDoubleWidth.isOn)
    {
        [printer SetZoom:(Byte)0x10];
    }
    if(swDoubleHeight.isOn)
    {
        [printer SetZoom:(Byte)0x01];
    }
    if(swUnderLine.isOn)
    {
        [printer SetUnderline:(Byte)0x02];//下划线
    }
    if(swBold.isOn)
    {
        [printer AddBold:(Byte)0x01];//粗体
    }
    if(swSmallFont.isOn)
    {
        [printer SetCharacterFont:(Byte)0x01];
        //mBloothPrinter.SetCharacterFont((byte)0x10);
    }
    if(swToWhite.isOn)
    {
        [printer SetBlackReversePrint:(Byte)0x01];
    }
    
    NSString *string = [NSString stringWithString:txtContent.text];
    [printer ImportData:string];
    [printer ImportData:@"\r"];
    [printer Excute];
    [printer ClearData];
}

- (IBAction)btnTest:(id)sender
{
    [printer Begin];
    //String tmpContent = mPrintContent.getText().toString();
    //mBloothPrinter.ImportData(tmpContent);
    Byte byte[]={0x12,0x54};
    NSData *data = [[NSData alloc] initWithBytes:byte length:2];
    [printer ImportData:data Len:2];	//设置倍高
    [printer Excute];
    [printer ClearData];
}

- (IBAction)btnPreferencesClick
{
    Preferences *pref = [[Preferences alloc] init];
    pref.printer = self.printer;
    
    AppDelegate *app = [[UIApplication sharedApplication] delegate];
    [app.navController pushViewController:pref animated:YES];
}

@end
