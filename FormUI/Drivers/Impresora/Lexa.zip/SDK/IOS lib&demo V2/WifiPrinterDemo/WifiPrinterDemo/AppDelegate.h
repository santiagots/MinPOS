//
//  AppDelegate.h
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <UIKit/UIKit.h>

#ifndef LANG
#define LANG(str) NSLocalizedStringFromTable(str, @"localizable", nil)
#endif

#ifndef MSGBOX
#define MSGBOX(msg) UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:NSLocalizedString(msg,nil)delegate:self cancelButtonTitle:NSLocalizedString(@"好",nil) otherButtonTitles:nil, nil];[alert show];
#endif

#ifndef IS_LANG_EN
#define IS_LANG_EN [[[[NSUserDefaults standardUserDefaults] objectForKey:@"AppleLanguages"] objectAtIndex:0] isEqualToString:@"en"]
#endif

#define IS_CH_SYMBOL(chr) ((int)(chr)>127)


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) UINavigationController *navController;
@end
