//
//  Preferences.h
//  WifiPrinterDemo
//
//  Created by qi yang on 13-5-13.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <UIKit/UIKit.h>

@class WifiPrinter;
@interface Preferences : UIViewController<UITextFieldDelegate>
{

}
@property (strong, nonatomic) WifiPrinter *printer;

@property (strong, nonatomic) IBOutlet UITextField *txtContent;
- (IBAction)btnPrintText:(id)sender;
- (IBAction)btnPrintPic:(id)sender;
- (IBAction)btnPrintBarcode:(id)sender;
- (IBAction)btnPrintInvoice:(id)sender;
- (IBAction)btnPrintTable:(id)sender;
@end
