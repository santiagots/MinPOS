//
//  WifiPrinter.h
//  WifiPrinterDemo
//
//  Created by qi yang on 13-6-6.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "AppDelegate.h"

//字符集
#define RT_CS_CP437                  0
#define RT_CS_KATAKANA               1
#define RT_CS_CP850                  2
#define RT_CS_CP860                  3
#define RT_CS_CP863                  4
#define RT_CS_CP865                  5
#define RT_CS_WP1251                 6
#define RT_CS_CP866                  7
#define RT_CS_MIK                    8
#define RT_CS_CP755                  9
#define RT_CS_CP862                  15
#define RT_CS_WCP1252                16
#define RT_CS_WCP1253                17
#define RT_CS_CP852                  18
#define RT_CS_CP858                  19
#define RT_CS_IRANII                 20
#define RT_CS_LATVIA                 21
#define RT_CS_CP864                  22
#define RT_CS_ISO88591               23
#define RT_CS_CP737                  24
#define RT_CS_WCP1257                25
#define RT_CS_THAI                   26
#define RT_CS_CP720                  27
#define RT_CS_CP855                  28
#define RT_CS_857                    29
#define RT_CS_WCP1250                30
#define RT_CS_CP775                  31
#define RT_CS_WCP1254                32
#define RT_CS_WCP1255                33
#define RT_CS_WCP1256                34
#define RT_CS_WCP1258                35
#define RT_CS_ISO88592               36
#define RT_CS_ISO88593               37
#define RT_CS_ISO88594               38
#define RT_CS_ISO88595               39
#define RT_CS_ISO88596               40
#define RT_CS_ISO88597               41
#define RT_CS_ISO88598               42
#define RT_CS_ISO88599               43
#define RT_CS_ISO885915              44
#define RT_CS_THAI2                  45
#define RT_CS_CP856                  46
#define RT_CS_CP874                  47

//国际字符集
#define RT_ICS_USA                   0
#define RT_ICS_FRANCE                1
#define RT_ICS_GERMANY               2
#define RT_ICS_ENGLAND               3
#define RT_ICS_DENMARKI              4
#define RT_ICS_SWEDEN                5
#define RT_ICS_ITALY                 6
#define RT_ICS_SPAINI                7
#define RT_ICS_JAPAN                 8
#define RT_ICS_NORWAY                9
#define RT_ICS_DENMARKII             10
#define RT_ICS_SPAINII               11
#define RT_ICS_LATIN                 12
#define RT_ICS_KOREAN                13
#define RT_ICS_SLOVENIA              14
#define RT_ICS_CHINA                 15

// 中文编码格式
#define RT_ENCODING_GBK              0
#define RT_ENCODING_UTF_8            1
#define RT_ENCODING_BIG5             3

//条形码／图像／文字对齐方式
#define RT_ALIGNMENT_LEFT            0
#define RT_ALIGNMENT_CENTER          1
#define RT_ALIGNMENT_RIGHT           2

//选择打印模式
#define RT_FT_DEFAULT                0x00
#define RT_FT_FONTA                  0x00
#define RT_FT_FONTB                  0x01
#define RT_FT_BOLD                   0x08
#define RT_FT_DHEIGHT                0x10
#define RT_FT_DWIDTH                 0x20
#define RT_FT_UNDERLINE              0x80

//选择HRI字符打印位置
#define RT_HRI_NONE                  0
#define RT_HRI_ABOVE                 1
#define RT_HRI_BELOW                 2
#define RT_HRI_BOTH                  3

//选择条形码系统并打印
#define RT_BCS_UPCA                  0x65
#define RT_BCS_UPCE                  0x66
#define RT_BCS_EAN13                 0x67
#define RT_BCS_EAN8                  0x68
#define RT_BCS_CODE39                0x69
#define RT_BCS_ITF                   0x70
#define RT_BCS_CODABAR               0x71
#define RT_BCS_CODE93                0x72
#define RT_BCS_CODE128               0x73

//设定字符大小
#define RT_TS_1WIDTH                 0x00
#define RT_TS_2WIDTH                 0x10
#define RT_TS_3WIDTH                 0x20
#define RT_TS_4WIDTH                 0x30
#define RT_TS_5WIDTH                 0x40
#define RT_TS_6WIDTH                 0x50
#define RT_TS_7WIDTH                 0x60
#define RT_TS_8WIDTH                 0x70

#define RT_TS_1HEIGHT                0x00
#define RT_TS_2HEIGHT                0x01
#define RT_TS_3HEIGHT                0x02
#define RT_TS_4HEIGHT                0x03
#define RT_TS_5HEIGHT                0x04
#define RT_TS_6HEIGHT                0x05
#define RT_TS_7HEIGHT                0x06
#define RT_TS_8HEIGHT                0x07

//实时传送打印机ID
#define RT_ID_MODLE                  49
#define RT_ID_NUMBER                 50
#define RT_ID_VERSION                65
#define RT_ID_FIRM                   66
#define RT_ID_PRINTERNAME            67
#define RT_ID_UARTNAME               68
#define RT_ID_ENCODINGTYPE           69

//实时状态传送
#define RT_STATE_PRINTER             1
#define RT_STATE_OFFLINE             2
#define RT_STATE_ERR                 3
#define RT_STATE_SENSOR              4

//实时打印机请求
#define RT_REQ_LINE                  1
#define RT_REQ_CLEAR                 2

//实时发生脉冲
#define RT_CASHDRAWER_PIN_2          0
#define RT_CASHDRAWER_PIN_5          1

//选择位图模式
#define RT_DENSITY_SINGLE_8          0
#define RT_DENSITY_DOUBLE_8          1
#define RT_DENSITY_SINGLE_24         32
#define RT_DENSITY_DOUBLE_24         33

//设定／解除下划线模式
#define RT_UNDERLINE_DIS             0
#define RT_UNDERLINE_1               1
#define RT_UNDERLINE_2               2

//选择字型
#define RT_FONT_A                    0
#define RT_FONT_B                    1

//设置／解除顺时针90度旋转
#define RT_CLOCKWISE_DIS             0
#define RT_CLOCKWISE_EN              1

//设定位图模式
#define RT_BMP_NORMAL                0
#define RT_BMP_DOUBLEWIDTH           1
#define RT_BMP_DOUBLEHEIGHT          2
#define RT_BMP_FOURTHTIMES           3

//选择HRI字符字型
#define RT_HRI_FONTA                 0
#define RT_HRI_FONTB                 1

//设定／解除反白打印模式
#define RT_INVERSE_DIS               0x00
#define RT_INVERSE_EN                0x01

//条形码宽度
#define RT_BARCODE_1                 2
#define RT_BARCODE_2                 3
#define RT_BARCODE_3                 4
#define RT_BARCODE_4                 5
#define RT_BARCODE_5                 6

//在页模式下选择打印方向
#define RT_DIRECTION_LEFT_RIGHT      0
#define RT_DIRECTION_BOTTOM_TOP      1
#define RT_DIRECTION_RIGHT_LEFT      2
#define RT_DIRECTION_TOP_BOTTOM      3

//设置／解除粗体
#define RT_BOLD_DIS                  0x00
#define RT_BOLD_EN                   0x01

//切纸模式选择
#define RT_CUT_PARTIAL               0x31
#define RT_CUT_WITHFEED              0x42

//设置／解除颠倒打印模式
#define RT_INVERT_DIS                0x00
#define RT_INVERT_EN                 0x01

//端口选择
#define RT_CONNECTION_WIFI           0x0000
#define RT_CONNECTION_ETHERNET       0x0001
#define RT_CONNECTION_BLUETOOTH      0x0002



@class AsyncSocket;
@interface WifiPrinter : NSObject
{
@private
    AsyncSocket * asyncSocket;
    Byte* mCmdBuffer;
    int mIndex;
    id delegate;
    
    BOOL bConnOK;
    BOOL bDisconnOK;
    BOOL bSendOK;
}
- (id) initWithDelegate:(id)de;
- (BOOL) InitPrinter;
- (void) ImportData:(NSData*)data Len:(int)len;
- (void) ImportData:(NSString*) data;
//- (void) ImportData:(Byte[])data and:(bool)isGBK;
- (void) ClearData;
- (void) WakeUpPrinter;
- (void) Begin;
- (BOOL) Excute;

- (void) HT;
- (void) LF;
- (void) CR;
- (void) SelftestPrint;
- (void) SetRightSpace:(Byte)Distance;
- (void) SetAbsoluteprintPosition:(Byte)nL highByte:(Byte)nH;
- (void) SetRelativeprintPosition:(Byte)nL highByte:(Byte)nH;
- (void) SetDefaultLineSpacing;
- (void) SetLineSpacing:(Byte)LineSpacing;
- (void) SetLeftStartSpacing:(Byte)nL highByte:(Byte)nH;
- (void) SetAreaWidth:(Byte)nL highByte:(Byte)nH;

- (void) SetCharacterPrintmode:(Byte)CharacterPrintmode;
- (void) SetUnderline:(Byte)UnderLineEn;
- (void) AddBold:(Byte)BoldEn;
- (void) SetCharacterFont:(Byte)Font;
- (void) SetRotate:(Byte)RotateEN;
- (void) SetAlignMode:(Byte)AlignMode;
- (void) SetInvertPrint:(Byte)InvertModeEn;
- (void) SetZoom:(Byte)FontEnlarge;
- (void) SetBlackReversePrint:(Byte)BlackReverseEn;

- (void) SetChineseCharacterMode:(Byte)ChineseCharacterMode;
- (void) SelChineseCodepage;
- (void) CancelChineseCodepage;
- (void) SetChineseUnderline:(Byte)ChineseUnderlineEn;

- (void) OpenDrawer:(Byte)DrawerNumber startTime:(Byte)pulseStartTime endTime:(Byte)PulseEndTime;

- (void) CutPaper;
- (void) partialCutPaper;
- (void) FeedAndCutPaper:(Byte)CutMode;
- (void) FeedAndCutPaper:(Byte)CutMode feed:(Byte)FeedDistance;

- (void) AddBarCodePrint:(int)codeType :(NSData *)data;
- (void) UPCA:(NSData *)_data;
- (void) UPCE:(NSData *)_data;
- (void) EAN13:(NSData *)_data;
- (void) EAN8:(NSData *)_data;
- (void) CODE39:(NSData *)_data;
- (void) ITF:(NSData *)_data;
- (void) CODEBAR:(NSData *)_data;
- (void) CODE93:(NSData *)_data;
- (void) Code128_B:(NSData *)_data;

- (void) BeginPrintImage:(UIImage *)image;
@end


//private function.
@interface WifiPrinter()
- (void)connectHost:(NSString *)host PORT:(UInt16)port;
- (void)disconnect;
- (void)sendData:(NSData *)data;
//- (NSData *)readData;
- (void)threadFunc:(NSString *)flag;
@end






