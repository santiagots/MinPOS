//
//  WifiPrinterDelegate.h
//  WifiPrinterDemo
//
//  Created by qi yang on 13-6-8.
//  Copyright (c) 2013年 aisino. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WifiPrinterDelegate
@optional
- (void)onConnected:(BOOL)isSucceed;
- (void)onDisconnected:(BOOL)isSucceed;
- (void)onSend:(BOOL)isSucceed;
@end